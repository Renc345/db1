﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PR4.Classes;

namespace PR4.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPagq.xaml
    /// </summary>
    public partial class AddEditPagq : Page
    {
        private Group _currentgroup = new Group(); //экземпляр добавляемого пользователя
        public AddEditPagq(Group selectedUser) // в конструктор добавлен праметр типа User
        {
            InitializeComponent();
            if (selectedUser != null)
                _currentgroup = selectedUser;
            DataContext = _currentgroup;
        }

        private void Savebtn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();// Объект для сообщение об ошибке
            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentgroup.Group1))
                error.AppendLine("Укажите группу");
            if (string.IsNullOrWhiteSpace(_currentgroup.Para))
                error.AppendLine("Укажите пару");
            if (string.IsNullOrWhiteSpace(date.Text))
                error.AppendLine("Укажите дату");
            if (string.IsNullOrWhiteSpace(numberaudit.Text))
                error.AppendLine("Укажите номер аудитории");
            if (error.Length > 0)

            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentgroup.KodGroup == 0)
                universityEntities.GetContext().Group.Add(_currentgroup);//Добавить в контекст
            try
            {

                universityEntities.GetContext().SaveChanges();// Сохранить изменения
                MessageBox.Show("Данные сохраненны");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}

